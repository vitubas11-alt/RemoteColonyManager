package com.vitor.remotecolonymanager;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class RemoteColonyScreen extends Screen {
   private static final int PAGE = 4;
   private static List<NetworkHandler.OrderEntry> orders = new ArrayList<>();
   private static List<NetworkHandler.BuilderEntry> builders = new ArrayList<>();
   private static List<NetworkHandler.BuildingEntry> buildings = new ArrayList<>();
   private final Set<Integer> selectedOrders = new LinkedHashSet<>();
   private final List<Long> selectedBuilders = new ArrayList<>();
   private static boolean autoAssignBulk = true;
   private int tab = 1;
   private int orderPage = 0;
   private int builderPage = 0;
   private int buildingPage = 0;
   private int panelW;
   private int panelH;
   private int panelX;
   private int panelY;
   private int buildingPageSize = 1;
   private String message = "Carregando colônia...";

   public RemoteColonyScreen() {
      super(Component.literal("Remote Colony Manager"));
   }

   public static void openOrUpdate(List<NetworkHandler.OrderEntry> o, List<NetworkHandler.BuilderEntry> b, List<NetworkHandler.BuildingEntry> bd) {
      Minecraft mc = Minecraft.getInstance();
      orders = new ArrayList<>(o);
      builders = new ArrayList<>(b);
      buildings = new ArrayList<>(bd);
      if (!(mc.screen instanceof RemoteColonyScreen)) {
         mc.setScreen(new RemoteColonyScreen());
      }

      if (mc.screen instanceof RemoteColonyScreen screen) {
         screen.selectedOrders.removeIf(id -> orders.stream().noneMatch(v -> v.id == id));
         screen.selectedBuilders.removeIf(pos -> builders.stream().noneMatch(v -> v.positionId == pos));
         screen.clampPages();
         screen.message = "Dados atualizados.";
         screen.rebuildWidgets();
      }
   }

   private void calculateLayout() {
      this.panelW = Math.min(700, Math.max(240, this.width - 12));
      this.panelH = Math.min(430, Math.max(190, this.height - 12));
      this.panelX = (this.width - this.panelW) / 2;
      this.panelY = (this.height - this.panelH) / 2;
      this.buildingPageSize = Math.max(1, Math.min(4, (this.panelH - 155) / 76));
   }

   private void clampPages() {
      this.calculateLayout();
      this.orderPage = Math.max(0, Math.min(this.orderPage, Math.max(0, (orders.size() - 1) / 4)));
      this.builderPage = Math.max(0, Math.min(this.builderPage, Math.max(0, (builders.size() - 1) / 4)));
      this.buildingPage = Math.max(0, Math.min(this.buildingPage, Math.max(0, (buildings.size() - 1) / this.buildingPageSize)));
   }

   protected void init() {
      this.calculateLayout();
      this.clearWidgets();
      int x = this.panelX;
      int y = this.panelY;
      int tabWidth = (this.panelW - 28) / 2;
      this.addRenderableWidget(Button.builder(Component.literal("Ordens e construtores"), b -> {
         this.tab = 0;
         this.rebuildWidgets();
      }).bounds(x + 8, y + 39, tabWidth, 22).build());
      this.addRenderableWidget(Button.builder(Component.literal("Prédios e ações"), b -> {
         this.tab = 1;
         this.rebuildWidgets();
      }).bounds(x + 12 + tabWidth, y + 39, tabWidth, 22).build());
      if (this.tab == 0) {
         this.initOrdersTab(x, y);
      } else {
         this.initBuildingsTab(x, y);
      }

      int bottom = y + this.panelH - 29;
      this.addRenderableWidget(Button.builder(Component.literal("Atualizar"), b -> {
         this.message = "Atualizando...";
         NetworkHandler.refresh();
      }).bounds(x + 8, bottom, 85, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("Fechar"), b -> this.onClose()).bounds(x + this.panelW - 83, bottom, 75, 20).build());
   }

   private void initBuildingsTab(int x, int y) {
      int bottom = y + this.panelH - 55;
      int first = this.buildingPage * this.buildingPageSize;
      int buttonGap = 3;
      int buttonWidth = (this.panelW - 28 - buttonGap * 3) / 4;

      for (int i = first; i < Math.min(buildings.size(), first + this.buildingPageSize); i++) {
         NetworkHandler.BuildingEntry building = buildings.get(i);
         int row = i - first;
         int ry = y + 91 + row * 76;
         String[] labels = new String[]{"Construir", "Evoluir", "Reparar", "Remover"};
         String[] actions = new String[]{"BUILD", "UPGRADE", "REPAIR", "REMOVE"};
         boolean[] enabled = new boolean[]{building.build, building.upgrade, building.repair, building.remove};

         for (int a = 0; a < 4; a++) {
            String action = actions[a];
            Button button = Button.builder(Component.literal(labels[a]), b -> this.act(building, action))
               .bounds(x + 8 + a * (buttonWidth + buttonGap), ry + 39, buttonWidth, 20)
               .build();
            button.active = enabled[a];
            this.addRenderableWidget(button);
         }
      }

      int bulkWidth = Math.max(60, this.panelW / 2 - 60);
      this.addRenderableWidget(Button.builder(Component.literal("Evoluir tudo"), b -> {
         NetworkHandler.requestBulk("UPGRADE_ALL", autoAssignBulk);
         this.message = "Pedindo melhoria de todos os prédios...";
      }).bounds(x + 8, bottom, bulkWidth, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("Reparar tudo"), b -> {
         NetworkHandler.requestBulk("REPAIR_ALL", autoAssignBulk);
         this.message = "Pedindo reparo de todos os prédios...";
      }).bounds(x + this.panelW - 8 - bulkWidth, bottom, bulkWidth, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("Auto: " + (autoAssignBulk ? "SIM" : "NÃO")), b -> {
         autoAssignBulk = !autoAssignBulk;
         this.message = autoAssignBulk ? "Ordens novas serão atribuídas aos construtores livres." : "Ordens novas ficam sem atribuição.";
         this.rebuildWidgets();
      }).bounds(x + 98, y + this.panelH - 29, Math.max(50, this.panelW - 186), 20).build());
      Button previous = Button.builder(Component.literal("<"), b -> {
         this.buildingPage = Math.max(0, this.buildingPage - 1);
         this.rebuildWidgets();
      }).bounds(x + this.panelW / 2 - 48, bottom, 35, 20).build();
      previous.active = this.buildingPage > 0;
      this.addRenderableWidget(previous);
      Button next = Button.builder(Component.literal(">"), b -> {
         this.buildingPage++;
         this.clampPages();
         this.rebuildWidgets();
      }).bounds(x + this.panelW / 2 + 12, bottom, 35, 20).build();
      next.active = (this.buildingPage + 1) * this.buildingPageSize < buildings.size();
      this.addRenderableWidget(next);
   }

   private void initOrdersTab(int x, int y) {
      int bottom = y + this.panelH - 55;
      int colWidth = (this.panelW - 28) / 2;
      int firstOrder = this.orderPage * 4;
      int firstBuilder = this.builderPage * 4;

      for (int i = firstOrder; i < Math.min(orders.size(), firstOrder + 4); i++) {
         NetworkHandler.OrderEntry order = orders.get(i);
         int row = i - firstOrder;
         Button button = Button.builder(
               Component.literal((this.selectedOrders.contains(order.id) ? "[x] " : "[ ] ") + order.type + " #" + order.id), b -> {
                  if (order.available) {
                     if (!this.selectedOrders.add(order.id)) {
                        this.selectedOrders.remove(order.id);
                     }

                     this.message = this.selectedOrders.size() + " ordem(ns) selecionada(s).";
                     this.rebuildWidgets();
                  }
               }
            )
            .bounds(x + 8, y + 103 + row * 48, colWidth, 22)
            .build();
         button.active = order.available;
         this.addRenderableWidget(button);
      }

      for (int i = firstBuilder; i < Math.min(builders.size(), firstBuilder + 4); i++) {
         NetworkHandler.BuilderEntry builder = builders.get(i);
         int row = i - firstBuilder;
         long selectedCount = this.selectedBuilders.stream().filter(pos -> pos == builder.positionId).count();
         Button button = Button.builder(Component.literal((selectedCount > 0L ? "[x] " : "[+] ") + builder.position), b -> {
            if (builder.hasWorker) {
               if (!this.selectedBuilders.remove(builder.positionId)) {
                  this.selectedBuilders.add(builder.positionId);
               }
               this.message = this.selectedBuilders.size() + " construtor(es) selecionado(s).";
               this.rebuildWidgets();
            }
         }).bounds(x + 16 + colWidth, y + 103 + row * 48, colWidth, 22).build();
         button.active = builder.hasWorker;
         this.addRenderableWidget(button);
      }

      this.addRenderableWidget(Button.builder(Component.literal("Atribuir manual"), b -> this.manualAssign()).bounds(x + 8, bottom, colWidth, 20).build());
      this.addRenderableWidget(
         Button.builder(Component.literal("Distribuir automático"), b -> this.automaticAssign())
            .bounds(x + 16 + colWidth, bottom, colWidth, 20)
            .build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("Limpar seleção"), b -> {
         this.selectedBuilders.clear();
         this.message = "Seleção de construtores limpa.";
         this.rebuildWidgets();
      }).bounds(x + this.panelW / 2 - 42, y + this.panelH - 83, 84, 19).build());
      this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
         this.orderPage = Math.max(0, this.orderPage - 1);
         this.rebuildWidgets();
      }).bounds(x + 8, y + this.panelH - 83, 30, 19).build());
      this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
         this.orderPage++;
         this.clampPages();
         this.rebuildWidgets();
      }).bounds(x + colWidth - 22, y + this.panelH - 83, 30, 19).build());
      this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
         this.builderPage = Math.max(0, this.builderPage - 1);
         this.rebuildWidgets();
      }).bounds(x + 16 + colWidth, y + this.panelH - 83, 30, 19).build());
      this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
         this.builderPage++;
         this.clampPages();
         this.rebuildWidgets();
      }).bounds(x + this.panelW - 38, y + this.panelH - 83, 30, 19).build());
   }

   private void act(NetworkHandler.BuildingEntry building, String action) {
      NetworkHandler.requestBuildingAction(building.positionId, action);
      this.message = "Solicitação enviada: " + action + " - " + building.name;
   }

   private void manualAssign() {
      if (!this.selectedOrders.isEmpty() && !this.selectedBuilders.isEmpty()) {
         if (this.selectedOrders.size() != this.selectedBuilders.size()) {
            this.message = "Selecione a mesma quantidade dos dois lados.";
         } else {
            NetworkHandler.assignManual(new ArrayList<>(this.selectedOrders), new ArrayList<>(this.selectedBuilders));
            this.message = "Enviando atribuições...";
         }
      } else {
         this.message = "Selecione ordens e construtores.";
      }
   }

   private void automaticAssign() {
      if (this.selectedOrders.isEmpty()) {
         this.message = "Selecione as ordens.";
      } else {
         NetworkHandler.autoDistribute(new ArrayList<>(this.selectedOrders));
         this.message = "Enviando distribuição automática...";
      }
   }

   public void render(GuiGraphics g, int mx, int my, float pt) {
      this.renderBackground(g);
      int x = this.panelX;
      int y = this.panelY;
      g.fill(x, y, x + this.panelW, y + this.panelH, -266656720);
      g.fill(x, y, x + this.panelW, y + 30, -13350045);
      g.drawCenteredString(this.font, "REMOTE COLONY MANAGER", this.width / 2, y + 10, -1);
      if (this.tab == 1) {
         g.drawString(this.font, "PRÉDIOS DA COLÔNIA", x + 9, y + 72, -11414);
         if (buildings.isEmpty()) {
            g.drawString(this.font, "Nenhum prédio registrado encontrado.", x + 10, y + 105, -1);
         }

         int first = this.buildingPage * this.buildingPageSize;

         for (int i = first; i < Math.min(buildings.size(), first + this.buildingPageSize); i++) {
            NetworkHandler.BuildingEntry b = buildings.get(i);
            int ry = y + 88 + (i - first) * 76;
            g.drawString(this.font, b.name + " | Nível " + b.level, x + 9, ry, -1);
            g.drawString(this.font, b.position + " | " + b.reason, x + 9, ry + 25, -4602157);
         }

         g.drawString(this.font, "Prédios encontrados: " + buildings.size() + " | Página " + (this.buildingPage + 1), x + 9, y + this.panelH - 69, -1);
      } else {
         int colWidth = (this.panelW - 28) / 2;
         g.drawString(this.font, "ORDENS", x + 9, y + 76, -11414);
         g.drawString(this.font, "CONSTRUTORES", x + 16 + colWidth, y + 76, -11414);
         int first = this.orderPage * 4;

         for (int i = first; i < Math.min(orders.size(), first + 4); i++) {
            NetworkHandler.OrderEntry order = orders.get(i);
            g.drawString(this.font, order.location, x + 12, y + 130 + (i - first) * 48, -4602157);
         }

         first = this.builderPage * 4;

         for (int i = first; i < Math.min(builders.size(), first + 4); i++) {
            NetworkHandler.BuilderEntry builder = builders.get(i);
            String status = !builder.hasWorker ? "Sem trabalhador" : (builder.free ? "Livre" : "Ocupado");
            g.drawString(this.font, status + " | " + builder.citizens, x + 16 + colWidth, y + 130 + (i - first) * 48, -4602157);
         }

         g.drawString(
            this.font, "Ordens: " + this.selectedOrders.size() + " | Construtores: " + this.selectedBuilders.size(), x + 9, y + this.panelH - 69, -1
         );
      }

      g.drawString(this.font, this.message, x + 9, y + this.panelH - 14, -11414);
      super.render(g, mx, my, pt);
   }

   public boolean isPauseScreen() {
      return false;
   }
}
